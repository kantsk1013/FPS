
<!DOCTYPE HTML>
<html>
<head>

<title>Frontline Public School,Nawada,Bihar-About </title>
<link rel="icon" href="favicon.ico" sizes="16x16" type="image/ico">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- Custom Theme files -->
<link href="css/style.css" rel='stylesheet' type='text/css' />	
<script src="js/jquery.min.js"> </script>
<!--webfonts-->
<link href='http://fonts.googleapis.com/css?family=Arvo:400,700,400italic|PT+Sans:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
<!--//webfonts-->
</head>
<style>
#detail
{width:1100px;
height:500px;
border:8px solid #005db7;
box-shadow:4px 5px 2px;
align:center;
float:center;
}
#image
{top:460px;
position:absolute;
left:150px;
}
#content
{position:absolute;
left:580px;
top:450px;
}
</style>
<body>


	<!----- start-header---->
			<div id="home" class="header two">
					<div class="top-header">
						<div class="top-header-child">
						<div class="container">
						<img src="images/logo.png" class="img-logo"/>
						<div class="logo">
							<a href="index"><h1>FRONTLINE  &nbsp <span> Public School</span></h1></a>
							
					<!----start-top-nav---->
						<div class="top-menu">
							<span class="menu"> </span>
								<ul class="cl-effect-16">
								 <li><a href="index" data-hover="Home">Home</a></li>
								<li><a class="active" href="std-det" data-hover="Student Details">Student Details</a></li>
								<li><a  href="fee-det" data-hover="Fee Details">Fee Details</a></li>
								<li><a href="academic-det" data-hover="Results">Academic Details</a></li>
								
								<!---welcome user script-->
								<div class="user-menu">
								<p align="right">  <?php
									session_start();
										echo " Welcome , &nbsp".$user_id=$_SESSION['username'];
													?> </p>
								</div>
						</div>
								  <div class="clearfix"></div>
								  
								</ul>
							</div>
							
								<!-- script-for-menu -->
							<div class="clearfix"> </div>
					</div>
				</div>

			    <div class="clearfix"> </div>
			</div>
		</div>
		<!----- //End-slider---->
<!---start-slide-bottom--->
			<div class="about-section">
				 <div class="container">
				     <div class="about-head">
							<h3>Students Profile</h3>
							<p>Visit your Profile</p>
					 </div>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <div id="detail"><div id="image"> <image src="images/s2a.jpg" alt="" width=250px height=250px></div>
					<div id="content">hello guys this is fps official website</div></div>
<br><br><br>					
					<div class="left-border">
					 </div>
					 <div class="std-det">
							Student Name :
							<br>
							Roll No:
							<br>
							Standard:	
							<br>
							Section:
							<br>
							Class Teacher (currently pursuing) :
							<br>
							</div>
							<div id="main">
								<div id="left">
								<table>
								<tr>
								<td><img  src="images/bullet.jpg" width="20" height="20"></td>
								<td>Academic Details</tr>
								</tr>
								<tr>
								<td></td>
								<td>Personal Details</tr>
								</tr>
								<tr>
								<td></td>
								<td>Address Details</tr>
								</tr>
								<tr>
								<td></td>
								<td>FEE Details</tr>
								</tr>
								<tr>
								<td></td>
								<td>Disciplinary Details</tr>
								</tr>
								</table>
								
								</div>
								<div id="right">
								</div>
							</div>
					
				      	<div class="col-md-5 slide-about">
									<div class="side">
										 <div  id="top" class="callbacks_container">
												<ul class="rslides" id="slider4">
														<li>
														<img src="images/s1.jpg" class="img-responsive" alt="" />
														</li>
														<li>
														<img src="images/s2.jpg" class="img-responsive" alt="" />
														</li>
														<li>
															<img src="images/s1.jpg" class="img-responsive" alt="" />
														</li>
													 </ul>
												</div>
											</div>
								<script src="js/responsiveslides.min.js"></script>
							 <script>
								// You can also use "$(window).load(function() {"
								$(function () {
								  // Slideshow 4
								  $("#slider4").responsiveSlides({
									auto: true,
									pager:false,
									nav: true,
									speed: 500,
									namespace: "callbacks",
									before: function () {
									  $('.events').append("<li>before event fired.</li>");
									},
									after: function () {
									  $('.events').append("<li>after event fired.</li>");
									}
								  });
							
								});
							  </script>
							<!----//End-slider-script---->
						<div class="clearfix"> </div>
					</div>
					<div class="col-md-7 about-text">
       <font size=3px color=blue><i>
  <center>
" Wisdom sculptures freedom <br>
Freedom promotes knowledge<br>
Knowledge exudes love<br>
Love propels education<br>
Education visualizes dreams <br>and Dreams are touchstones<br/> of character!" </i></font></center><br><br>
	 

					    <p>Schools are the training grounds for the citizens of tomorrow. To ensure that Indians have a space in the global platform, we need to nurture and promote innovation in thinking. Children must be encouraged to think through a problem and come up with creative solutions and this must be ably supplemented with technological progress.</p>
						 <p>Finally, the future lies in the hands of individuals who are ready to learn all through their lives.The understanding and acknowledgment of this fact alone by all the stake-holders in the education sector, i.e. parent, child and teacher will bring about commitment and qualitative change in the teaching-learning process.</p>
						

					</div>
					<div class="clearfix"></div>
				 </div>
			</div>
       <!---start-about-bottom--->
		<div class="slide-bottom">
			<div class="slide-bottom-grids">
				 <div class="container">
					 <div class="col-md-6 slide-bottom-grid">
							<h3>Welcome!</h3>
							<p>Ruelloribus eget elemetum vel curleif end elit. for that matter even a relationship, for that matter even a relationship, Aean auctoetnliir pis terios. ante ipsummis fauulet utrice posere cubtsed leo pharetu nec augue. dui bibendum ornare elementum. In vel mi pellentesque.</p>
					 </div>
					 <div class="col-md-6 slide-bottom-grid">
					       <h3>Our Mission</h3>
						   <p>Ruelloribus eget elemetum vel curleif end elit. for that matter even a relationship, for that matter even a relationship, Aean auctoetnliir pis terios. ante ipsummis fauulet utrice posere cubtsed leo pharetu nec augue. dui bibendum ornare elementum. In vel mi pellentesque.</p>
					 </div>
					   <div class="clearfix"></div>
				 </div>
			 </div>
		</div>
		<div class="member-section">
			<div class="container">
				<div class="member-head">
						<h3>Our Members</h3>
					   <p>2015 Board Members</p>
					   </div>
			      <div class="members">
					   <div class="col-md-4 member-grids">
                              <a href="#"> <img src="images/m2.jpg" class="img-responsive" alt="" /></a>
								<h5>President</h5>
								<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
							</div>
							<div class="col-md-4 member-grids">
								<a href="#"> <img src="images/m3.jpg" class="img-responsive" alt="" /></a>
								<h5>Vice President</h5>
								<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>

							</div>
							<div class="col-md-4 member-grids">
								<a href="#"> <img src="images/m1.jpg" class="img-responsive" alt="" /></a>
								<h5>Chief of Staff</h5>
								<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
							</div>
							<div class="clearfix"> </div>
					   </div>
				  </div>
			</div>
		</div>
<!--/mid-bg-->
	<div class="mid-bg">
		<div class="container">
			<div class="mid-section">
							</div>
		</div>
	</div>
	<!--address-->
	<div id="contact" class="address">
			<h3>Our Offices</h3>
			<ul class="address-top">
				<li>F.P.S , South-East of R.M.W College</li>
				<li>Nawada, Bihar</li>
			</ul>
			<ul class="address-mid">
				 <li>F.P.S, Chatar, Hasapur</li>
				 <li>Narhat, Nawada</li>
			</ul>
			<ul class="address-bottom">
				 <li>F.P.S Web Team</li>
				 <li>+91-9040434795</li>
				 <li><a class="mail" href="mailto:admin@fpsnawada.com"> admin@fpsnawada.com </a></li>
			</ul>
		 <div class="clearfix"></div>
	</div>
	<!--//address-->
		<!----footer--->
			<div class="footer">
				<div class="container">
					<div class="copy">
		              <p>&copy; 2015 All Rights Reserved Design by <a href="http://www.facebook.com/akash5493/">Akash & Aman</a> </p>
		            </div>
					
				</div>
			</div>
	<!--start-smoth-scrolling-->
			<script type="text/javascript">
								jQuery(document).ready(function($) {
									$(".scroll").click(function(event){		
										event.preventDefault();
										$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
									});
								});
								</script>
							<!--start-smoth-scrolling-->
						<script type="text/javascript">
									$(document).ready(function() {
										/*
										var defaults = {
								  			containerID: 'toTop', // fading element id
											containerHoverID: 'toTopHover', // fading element hover id
											scrollSpeed: 1200,
											easingType: 'linear' 
								 		};
										*/
										
										$().UItoTop({ easingType: 'easeOutQuart' });
										
									});
								</script>
		<a href="#home" id="toTop" class="scroll" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>


</body>
</html>